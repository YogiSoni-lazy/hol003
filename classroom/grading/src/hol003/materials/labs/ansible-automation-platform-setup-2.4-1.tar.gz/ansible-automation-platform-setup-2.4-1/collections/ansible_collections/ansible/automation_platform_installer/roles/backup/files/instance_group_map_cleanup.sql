-- Remove mapping tables
DROP TABLE tmp_organization_instancegroup_name_map;
DROP TABLE tmp_jobtemplate_instancegroup_name_map;
DROP TABLE tmp_inventory_instancegroup_name_map;
